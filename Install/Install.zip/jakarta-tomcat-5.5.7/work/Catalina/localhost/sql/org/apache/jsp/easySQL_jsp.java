package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import webBoltons.dataAccess.*;

public final class easySQL_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("  <title>Easy SQL</title>\r\n");
      out.write("</head>\r\n");
      out.write("\r\n");
      out.write("<body>\r\n");
      out.write("\r\n");
      out.write(" ");
      EasySQL easy = null;
      synchronized (session) {
        easy = (EasySQL) _jspx_page_context.getAttribute("easy", PageContext.SESSION_SCOPE);
        if (easy == null){
          easy = new EasySQL();
          _jspx_page_context.setAttribute("easy", easy, PageContext.SESSION_SCOPE);
        }
      }
      out.write("\r\n");
      out.write(" \r\n");
      out.write("<div style=\"text-align: center;\"> <img alt=\"\" src=\"easySQL.JPG\" style=\"width: 330px; height: 127px;\"><br> </div>\r\n");
      out.write("\r\n");
      out.write(" ");
 String d1 = request.getParameter("d1");
    if (d1 == null) d1= "";       
    String d2 = request.getParameter("d2");
    if (d2 == null) d2= "";
    String d3 = request.getParameter("d3");
    if (d3 == null) d3= "";       
    String d4 = request.getParameter("d4");
    if (d4 == null) d4= "";
    String qry = request.getParameter("qry");
    if (qry == null) qry= "";  
      out.write(" <h2> ");
      out.print( qry );
      out.write(" </h2> \r\n");
      out.write(" \r\n");
      out.write("  ");
 if (!easy.openConnection(d1, d2, d3, d4)) { 
      out.write("\t\r\n");
      out.write("  \r\n");
      out.write("   <h4> Not Connected to Database </h4> \r\n");
      out.write("  \r\n");
      out.write("  ");
 } else if(!qry.equals("")) { 
  		String [] headings = easy.openTable(qry);
   		
      out.write(" <table BORDER=1 CELLPADDING=5 CELLSPACING=5> <tr> ");
 
   		for (int x = 0; x < headings.length; x++) {
      out.write("\r\n");
      out.write("\t   \t         <td BGCOLOR=DDDDDD > ");
      out.print(headings[x]);
      out.write(" </td>   \t   \t    \r\n");
      out.write(" \t   ");
 } 
      out.write(" </tr> ");
  
		while (easy.getMoreColumns(qry)) {
			String[] r = easy.getColumns();
			
      out.write(" <tr> ");

			for (int x = 0; x < r.length; x++) { 
      out.write(" \r\n");
      out.write("\t\t\t <td BGCOLOR=LIGHTBLUE > ");
      out.print( r[x] );
      out.write("</td>\r\n");
      out.write("\t    \t");
}
      out.write("\r\n");
      out.write("\t    </tr>\r\n");
      out.write("\t    ");
}
      out.write("\r\n");
      out.write("\t    </table>\r\n");
      out.write("\t  \r\n");
      out.write("\t  <p> ");
      out.print( qry );
      out.write(" - Selected Rows: ");
      out.print( easy.getRowCount() );
      out.write(" </p>\r\n");
      out.write("\r\n");
 } 
      out.write("\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<form method=\"post\" action=\"easySQL.jsp\">\r\n");
      out.write("  <table style=\"text-align: left; width: 663px; height: 124px;\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\r\n");
      out.write("    <tbody>\r\n");
      out.write(" \r\n");
      out.write("      <tr> <td style=\"vertical-align: top;\"> Driver: </td>\r\n");
      out.write("        <td style=\"vertical-align: top;\"><input value=\"");
      out.print( d1 );
      out.write("\" size=\"80\" name=\"d1\"></td>\r\n");
      out.write("      </tr>\r\n");
      out.write("    \r\n");
      out.write("      <tr>\r\n");
      out.write("        <td style=\"vertical-align: top;\"> URL:  </td>\r\n");
      out.write("        <td style=\"vertical-align: top;\"><input  value=\"");
      out.print( d2 );
      out.write("\" size=\"80\" name=\"d2\"></td>\r\n");
      out.write("      </tr>\r\n");
      out.write("      \r\n");
      out.write("      <tr>\r\n");
      out.write("        <td style=\"vertical-align: top;\"> User:  </td>\r\n");
      out.write("        <td style=\"vertical-align: top;\"><input value=\"");
      out.print( d3 );
      out.write("\" size=\"80\" name=\"d3\"></td>\r\n");
      out.write("      </tr>\r\n");
      out.write("      \r\n");
      out.write("      <tr>\r\n");
      out.write("        <td style=\"vertical-align: top;\"> Password: </td>  \r\n");
      out.write("        <td style=\"vertical-align: top;\"><input value=\"");
      out.print( d4 );
      out.write("\" size=\"80\" name=\"d4\"></td>\r\n");
      out.write("      </tr>\r\n");
      out.write("\r\n");
      out.write("      \r\n");
      out.write("       \r\n");
      out.write("      <tr>\r\n");
      out.write("       <td style=\"vertical-align: top;\"> SQL Statement:</td>\r\n");
      out.write(" \t\t<td style=\"vertical-align: top;\"> \r\n");
      out.write(" \t\t    <textarea rows=\"10\" name=\"qry\" cols=\"60\"></textarea></td>\r\n");
      out.write("      </tr>\r\n");
      out.write("\r\n");
      out.write("    </tbody>\r\n");
      out.write("  </table>\t\r\n");
      out.write("\t\r\n");
      out.write("\t<p><input type=\"submit\" name=\"b1\" value=\"Execute/Commit\" /></p>\r\n");
      out.write("  </form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
