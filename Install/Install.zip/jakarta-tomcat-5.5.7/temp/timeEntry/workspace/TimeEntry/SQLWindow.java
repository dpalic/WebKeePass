
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webBoltOns.dataContol.DataAccess;


public class SQLWindow
              extends HttpServlet {

  DataAccess dataAccess = null;
  int rowCount = 0, numberOfColumns = 0;

  String columnNames[], details[], colvalues[];
  ResultSet metaDataSet;
  ResultSetMetaData metaData;
  DatabaseMetaData metaDataDB;
  Statement statement;
  PreparedStatement prepstat;
  ResultSet resultSet;
  boolean TableIsOpen;
  String tableName;
  java.sql.Connection con;

  public void init(ServletConfig config) throws ServletException {
    super.init(config);
    dataAccess = new DataAccess("ConfigFile1.xml" ,null );
    dataAccess.initDataAccess();
  }

  public void doGet(HttpServletRequest req,
                    HttpServletResponse res) throws IOException, ServletException {
    req.getSession(true);
    res.setContentType("text/html");
    PrintWriter out = res.getWriter();
    out.println("<html><head><title>SQL Entry");
    out.println("</title></head><body>");
    out.println("<h2><u>SQL Entry</u></h2>");
    String qry = checkNull(req.getParameter("T1"));
    if (!qry.equals("")) {
      execSQL(out, qry);
    } else {
      execOpenQry(out, qry);
    }
    out.println("</BODY></HTML>");
  }


  public void doPost(HttpServletRequest req,
                     HttpServletResponse res) throws IOException, ServletException {
    this.doGet(req, res);
  }


  private void execOpenQry(PrintWriter out, String qry) {
    out.println("<form method=\"POST\" action=\"SQLWindow\">");
    out.println("<p><textarea rows=\"15\" name=\"T1\" cols=\"80\"></textarea>");
    out.println("<input type=\"submit\" value=\"Execute\" name=\"B1\"></p>");
    out.println("</form>");
  }

  private void execSQL(PrintWriter out, String qry) {
    out.println("<TABLE BORDER=1 CELLPADDING=5 CELLSPACING=5>");
    out.println("<TR>");
    String[] c = openTable(qry);
    for (int x = 0; x < c.length; x++) {
      out.println("<TD BGCOLOR=DDDDDD > " + checkNull(c[x]) + " </TD>");
    }
    out.println("</TR>");
    while (getMoreColumns(qry)) {
      String[] r = getColumns();
      out.println("<TR>");
      for (int x = 0; x < r.length; x++) {
        out.println("<TD BGCOLOR=LIGHTBLUE > " + checkNull(r[x]) + " </TD>");
      }
      out.println(" </TR>");

    }
    out.println(" </TABLE>");
     out.println("<h4>" + qry +" </h4>");
    out.println("<h4> " + rowCount + " Rows </h4>");
    execOpenQry(out, qry);
  }

//****************************************************************************
//**
    public String[] openTable(String sql) {
      try {
        rowCount = 0;
        TableIsOpen = execQry(sql.trim());
        if (TableIsOpen) {
          columnNames = getHeadings(sql);
        } else {
          columnNames = new String[2];
          columnNames[0] = "error";
          columnNames[1] = "Tabel Closed?";
        }
        return columnNames;
      } catch (SQLException err) {
        columnNames = new String[2];
        columnNames[0] = "err[1]: " + sql;
        columnNames[1] = err.toString();
        details = new String[4];
        details[0] = sql;
        details[1] = "SQL Error " + err.getCause();
        details[2] = err.getMessage();
        details[3] = err.getLocalizedMessage();
        return columnNames;
      }
    }

//****************************************************************************
//**
    private String[] getHeadings(String sql) throws SQLException {
      if (sql.toUpperCase().startsWith("DESC")) {
        int rows = statement.getUpdateCount();
        columnNames = new String[5];
        columnNames[0] = "Column Name";
        columnNames[1] = "Column Desc";
        columnNames[2] = "Data Type";
        columnNames[3] = "Data Length";
        columnNames[4] = "Data Prec";
        numberOfColumns = 5;
        TableIsOpen = true;
        return columnNames;
      } else if (sql.toUpperCase().startsWith("SELECT")
                 || sql.toUpperCase().startsWith("SHOW")) {
        metaData = resultSet.getMetaData();
        numberOfColumns = metaData.getColumnCount();
        columnNames = new String[numberOfColumns];
        for (int col = 0; col < numberOfColumns; col++) {
          columnNames[col] = metaData.getColumnLabel(col + 1);
        }
        TableIsOpen = true;
        return columnNames;
      } else {
        int rows = statement.getUpdateCount();
        columnNames = new String[2];
        columnNames[0] = rows + " Rows Updated";
        columnNames[1] = sql;
        details = new String[3];
        details[0] = sql;
        details[1] = rows + " Rows Updated";
        TableIsOpen = false;
        return columnNames;
      }
    }

//****************************************************************************
//**
    private boolean execQry(String sql) throws SQLException {

        
      statement = dataAccess.execConnectUpdate(); 
      if (sql.toUpperCase().startsWith("SELECT")) {
        resultSet = statement.executeQuery(sql);
        details = new String[2];
        details[0] = sql;
        details[1] = statement.getMaxRows() + " selected rows";
        return true;
      } else if (sql.toUpperCase().startsWith("DESC")) {
        resultSet = statement.executeQuery("SELECT * FROM "
                                           + sql.substring(4, sql.length()));
        details = new String[2];
        details[0] = sql;
        details[1] = statement.getMaxRows() + " selected rows";
        return true;
      } else {
        statement.execute(sql);
        details = new String[2];
        details[0] = sql;
        details[1] = statement.getMaxRows() + " selected rows";
        return true;
      }
    }

//****************************************************************************
//**
    public boolean getMoreColumns(String sql) {
      if (!TableIsOpen) {
        return false;
      } else if (sql.toUpperCase().startsWith("SELECT")
                 || sql.toUpperCase().startsWith("SHOW")) {
        return this.getSELECT(sql);
      } else if (sql.toUpperCase().startsWith("DESC")) {
        return this.getDESC(sql);
      } else {
        return false;
      }
    }

//****************************************************************************
//**
    private boolean getSELECT(String sql) {
      try {
        if (resultSet.next()) {
          colvalues = new String[numberOfColumns];
          for (int i = 1; i <= numberOfColumns; i++) {
            colvalues[i - 1] = resultSet.getString(i);
          }
          rowCount++;
          return true;
        } else {
          dataAccess.execClose(statement);
          return false;
        }
      } catch (Exception err) {
        colvalues = new String[2];
        colvalues[0] = "err[1]: " + sql;
        colvalues[1] = "err[2]: " + err;

        details = new String[2];
        details[0] = sql;
        details[1] = "error: " + err;

        try {
          dataAccess.execClose(statement);
          return false;
        } catch (Exception serr) {
          System.err.println("can't close DB connention" + serr.getMessage());
        }
        return false;
      }
    }

//****************************************************************************
//**
    private boolean getDESC(String sql) {
      try {
        colvalues = new String[5];

        metaData = resultSet.getMetaData();
        if (metaData.getColumnCount() == rowCount) {
          dataAccess.execClose(statement);
          return false;
        } else {
          columnNames = new String[numberOfColumns];
          colvalues[0] = metaData.getColumnLabel(rowCount + 1);
          colvalues[1] = metaData.getColumnName(rowCount + 1);
          colvalues[2] = metaData.getColumnTypeName(rowCount + 1);
          colvalues[3] = Integer.toString(metaData.getColumnDisplaySize(rowCount + 1));
          colvalues[4] = Integer.toString(metaData.getPrecision(rowCount + 1));
          rowCount++;
          return true;
        }
      } catch (Exception err) {
        colvalues = new String[2];
        colvalues[0] = "err[1]: " + sql;
        colvalues[1] = "err[2]: " + err;
        details = new String[2];
        details[0] = sql;
        details[1] = "error: " + err;
        try {
          dataAccess.execClose(statement);
          return false;
        } catch (Exception serr) {
          System.err.println("can't close DB connention" + serr.getMessage());
        }
        return false;
      }
    }

//****************************************************************************
//**
    public String[] getColumns() {
      String[] c = new String[numberOfColumns];
      for (int i = 1; i <= numberOfColumns; i++) {
        c[i - 1] = colvalues[i - 1];
      }
      return c;
    }

//****************************************************************************
//**
    public String checkNull(String isnull) {
      try {
        if (isnull.equals(null)) {
          return "";
        } else {
          return isnull;
        }
      } catch (NullPointerException nerr) {
        return "";
      }
    }

}
