/**
 * <p>Title: TimeEntryEmployeest</p>
 * <p>Description: Employee Class</p>
 *
 * 
 * @author  [User/]
 * @version 1.0
 */


/*
Class Description:
  
*/


/*
Tables/Data Definition:
  
*/



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import webBoltOns.dataContol.DataAccess;
import webBoltOns.dataContol.DataSet;
import webBoltOns.dataContol.StandardTableDefinition;


public class TimeEntryEmployees {

 TableFieldDefinition tableFields = new TableFieldDefinition();
	
 public TimeEntryEmployees() {}
 

 
 /**/
 
 public DataSet getEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {     
   String keyField1 =  appletDataSet.getStringField("EmployeeID");
      java.sql.ResultSet resultSet;
      java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
      try {
         	resultSet = sqlStatement.executeQuery(
          		"Select * from Employees Where EmployeeID =  " + keyField1 + " ");
          if (resultSet.next()) 
            for (int x = 0; x < tableFields.getColumnCount(); x++) {
              String field = tableFields.getFieldByIndex(x),
			         type = tableFields.getFieldType(field);
              appletDataSet.put(field, servletDataAccess.getFieldValue(resultSet, field, type));
        }
        else 
              appletDataSet.addMessage("Record Not found", "30", null, null);
      
       resultSet.close();	
    } catch (Exception exception) {
      servletDataAccess.logMessage(" *TimeEntryEmployees.getEmployees* -- " + exception);
      appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
    } finally {
      servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }


 public DataSet getEmployeeName(DataSet appletDataSet, DataAccess servletDataAccess) {     
    String keyField1 =  appletDataSet.getStringField("EmployeeID");
       java.sql.ResultSet resultSet;
       java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
       String name = "";
       try {
          	resultSet = sqlStatement.executeQuery(
           		"Select FirstName, LastName  from Employees Where EmployeeID =  " + keyField1 + " ");
           if (resultSet.next()) 
               name = servletDataAccess.getFieldValue(resultSet, "FirstName", "CHR") 
		  	           + " " + servletDataAccess.getFieldValue(resultSet, "LastName", "CHR");
               
         resultSet.close();	
     } catch (Exception exception) { 
     } finally {
       servletDataAccess.execClose(sqlStatement);
     }
     
     appletDataSet.putStringField("EmployeeName", name);
   return appletDataSet;
   }


 
  /**/ 

  public DataSet updEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 = appletDataSet.getStringField("EmployeeID");
    if(editEmployees(appletDataSet,  servletDataAccess))
    	if(isNewEmployees(keyField1 ,servletDataAccess))
    		appletDataSet = insertIntoEmployees(appletDataSet,  servletDataAccess);
    	else 
    		appletDataSet = updateIntoEmployees(appletDataSet,  servletDataAccess);	
    return appletDataSet;
  }
   

  public DataSet getNextEmployeesNumber(DataSet appletDataSet,
                                             DataAccess servletDataAccess) {
      return appletDataSet;
  }

  private boolean editEmployees(DataSet appletDataSet, 
                                             DataAccess servletDataAccess){

     if(appletDataSet.getStringField("EmployeeNumber").equals("")) {
      	appletDataSet.addMessage("Employee Number is blanks","30","EmployeeNumber",null);
      	return false;
      }
      
      
	  return true;
  }


  public boolean isNewEmployees(String keyfField1, DataAccess servletDataAccess){
     java.sql.ResultSet resultSet;
     java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
     boolean newRecord = false;
     try {
     	resultSet = sqlStatement.executeQuery(
     			"Select EmployeeID from Employees Where EmployeeID =  " + keyfField1 +" "); 
  
     	if (!resultSet.next())
     		newRecord = true;

     	resultSet.close();         
     } catch (Exception exception) {
       servletDataAccess.logMessage(" *TimeEntryEmployees.isNewEmployees* -- " + exception);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
     }
     return newRecord;
  }
 
  
  private DataSet insertIntoEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "", updateValues = "";
  		String updateableFields [] = appletDataSet.getUpdateableFields(); 
           for (int x = 0; x < updateableFields.length; x++) {
           if(tableFields.isValidTableColumn(updateableFields[x])) {
                String field = updateableFields[x],
	                   type  = tableFields.getFieldType(field); 
            	updateFields = servletDataAccess.addToArgumentList(updateFields, field);
            	updateValues = servletDataAccess.addToArgumentList(updateValues, "?");
            }            
           }
           sqlUpdateStatement = servletDataAccess.execPreparedConnect(
                   "Insert Into Employees (" + updateFields + " ) Values (" + updateValues + ")");
           
           for (int x = 0; x < updateableFields.length; x++) {
            if(tableFields.isValidTableColumn(updateableFields[x])) {
           	 String field = updateableFields[x],
			       type = tableFields.getFieldType(field);
           	 servletDataAccess.setPreparedValue(
           			sqlUpdateStatement,
					x + 1,
					field,
					type,
					appletDataSet);		
            }              
           }         	
            sqlUpdateStatement.executeUpdate();

            appletDataSet.addMessage("Employees Added", "10", null, null);
         } catch (Exception exception) {
            servletDataAccess.logMessage(" *TimeEntryEmployees.insertIntoEmployees* -- " + exception);
         	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
         } finally {
           servletDataAccess.execClose(sqlUpdateStatement);
         }
       return appletDataSet;
     }
                      

  private DataSet updateIntoEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "";
  		String updateableFields [] = appletDataSet.getUpdateableFields(); 
  		for (int x = 1; x < updateableFields.length; x++)
  			if(tableFields.isValidTableColumn(updateableFields[x]))  		
  			  updateFields = servletDataAccess.addToArgumentList(updateFields, 
  				   	  updateableFields[x]  + " = ? ");
               	
  		sqlUpdateStatement = servletDataAccess.execPreparedConnect(
  				"Update Employees SET " + updateFields + " Where EmployeeID =  " + 
					appletDataSet.getStringField("EmployeeID") + " ");
               	
                     for (int x = 1; x < updateableFields.length; x++) {
                      if(tableFields.isValidTableColumn(updateableFields[x])) { 		
                       	String field = updateableFields[x],
					           type = tableFields.getFieldType(field);
                       	servletDataAccess.setPreparedValue(
                   			sqlUpdateStatement,
        					x,
        					field,
        					type,
        					appletDataSet);		
                      }
                     }
                     sqlUpdateStatement.executeUpdate();
                     appletDataSet.addMessage("Employees Updated", "10", null, null);
                 } catch (Exception exception) {
                    servletDataAccess.logMessage(" *TimeEntryEmployees.updateIntoEmployees* -- " + exception);
                 	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
                 } finally {
                   servletDataAccess.execClose(sqlUpdateStatement);
                 }
               return appletDataSet;
             }




  /**/

  public DataSet delEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 = appletDataSet.getStringField("EmployeeID");
   java.sql.Statement sqlStatement = servletDataAccess.execConnectUpdate();
     try {
       sqlStatement.executeUpdate(
       		"Delete from Employees Where EmployeeID =  " + keyField1 + " ");
       appletDataSet.addMessage("Record Deleted", "10", null, null);
     }  catch (Exception exception) {
        servletDataAccess.logMessage(" *TimeEntryEmployees.delEmployees* -- " + exception);
     	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
    }
     return appletDataSet;
  }




 /**/
 public DataSet nxtEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 =  appletDataSet.getStringField("EmployeeID");
   ResultSet resultSet;
   java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
   try {
   		resultSet = sqlStatement.executeQuery(
   			"Select * from Employees Where EmployeeID >  " + keyField1 +"  Order By EmployeeID");
       if (resultSet.next()) {
         for (int x = 0; x < tableFields.getColumnCount(); x++) {
        	String field = tableFields.getFieldByIndex(x),
	               type = tableFields.getFieldType(field);
         	appletDataSet.put(field, 
         			          servletDataAccess.getFieldValue(resultSet, field, type));
         }
       } else {
       	appletDataSet.addMessage("Record Not found", "30", null, null);
       }
        resultSet.close();
      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeEntryEmployees.nxtEmployees* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
      }
    
    return appletDataSet;
  }




  /**/
  public DataSet prvEmployees(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 =  appletDataSet.getStringField("EmployeeID");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
    try {
    		resultSet = sqlStatement.executeQuery(
    			"Select * from Employees Where EmployeeID <  " + keyField1 +"  Order By EmployeeID DESC");
        if (resultSet.next()) {
          for (int x = 0; x < tableFields.getColumnCount(); x++) {
         	String field = tableFields.getFieldByIndex(x),
 	               type = tableFields.getFieldType(field);
          	appletDataSet.put(field, 
          			          servletDataAccess.getFieldValue(resultSet, field, type));
          }
        } else {
        	appletDataSet.addMessage("Record Not found", "30", null, null);
        }
         resultSet.close();
       } catch (Exception exception) {
          servletDataAccess.logMessage(" *TimeEntryEmployees.prvEmployees* -- " + exception);
       	  appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
       } finally {
       	servletDataAccess.execClose(sqlStatement);
       }
     
     return appletDataSet;
   }




  /**/

  public DataSet getEmployeesList(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
    String keyField1 = (String) appletDataSet.get("@EmployeeID");
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("Table1");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From Employees ";
    
     sql = servletDataAccess.addToSearchWhereClause(sql,"EmployeeID", "CHR", 
     		                                keyField1);
     sql = servletDataAccess.addToSearchWhereClause(sql,"FirstName", "CHR", 
     		                                appletDataSet.getStringField("@FirstName"));
     sql = servletDataAccess.addToSearchWhereClause(sql,"LasttName", "CHR", 
             								appletDataSet.getStringField("@LastName"));
     sql = servletDataAccess.addToSearchWhereClause(sql,"Title", "CHR", 
             								appletDataSet.getStringField("@Title"));
      
    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		tableFields.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("Table1", cstmrv1);

      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeEntryEmployees.getEmployeesList* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }



 
//**************************************************************************************************** 
  class TableFieldDefinition 
        extends StandardTableDefinition { 
	TableFieldDefinition(){
		setTable(tableColumNames,tableFieldTypes);	
	}
   private final  String[] tableColumNames = {
          "EmployeeID" , 
          "EmployeeNumber" , 
          "FirstName" , 
          "LastName" , 
          "Title" , 
          "Extension" , 
          "Address" , 
          "City" , 
          "StateOrProvince" , 
          "PostalCode" , 
          "Country" , 
          "WorkPhone" , 
          "BillingRate" , 

        };

    private final  String[] tableFieldTypes = {
	 "INT", 	 // EmployeeID
	 "CHR", 	 // EmployeeNumber
	 "CHR", 	 // FirstName
	 "CHR", 	 // LastName
	 "CHR", 	 // Title
	 "CHR", 	 // Extension
	 "CHR", 	 // Address
	 "CHR", 	 // City
	 "CHR", 	 // StateOrProvince
	 "CHR", 	 // PostalCode
	 "CHR", 	 // Country
	 "CHR", 	 // WorkPhone
	 "CHR", 	 // BillingRate

            };
   }
}
