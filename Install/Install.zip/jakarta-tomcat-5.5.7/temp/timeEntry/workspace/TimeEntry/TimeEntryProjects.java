/**
 * <p>Title: TimeEntryProjectst</p>
 * <p>Description: </p>
 *
 * 
 * @author  [User/]
 * @version 1.0
 */


/*
Class Description:
  
*/


/*
Tables/Data Definition:
  
*/



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import webBoltOns.dataContol.DataAccess;
import webBoltOns.dataContol.DataSet;
import webBoltOns.dataContol.StandardTableDefinition;


public class TimeEntryProjects {

 TableFieldDefinition tableFields = new TableFieldDefinition();

 
 public TimeEntryProjects() {}
 

 
 /**/
 
 public DataSet getProjects(DataSet appletDataSet, DataAccess servletDataAccess) {     
   String keyField1 =  appletDataSet.getStringField("ProjectID");
      java.sql.ResultSet resultSet;
      java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
      TimeEntryClient clients = new TimeEntryClient();
      TimeEntryEmployees employee = new TimeEntryEmployees(); 
      try {
         	resultSet = sqlStatement.executeQuery(
          		"Select * from Projects Where ProjectID =  " + keyField1 + " ");
          if (resultSet.next()) { 
            for (int x = 0; x < tableFields.getColumnCount(); x++) {
              String field = tableFields.getFieldByIndex(x),
			         type = tableFields.getFieldType(field);
              if(type != null)
              	appletDataSet.put(field, servletDataAccess.getFieldValue(resultSet, field, type));
        }
            
          appletDataSet = clients.getClientCompanyName(appletDataSet, servletDataAccess); 
          appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);
          
      } else 
              appletDataSet.addMessage("Record Not found", "30", null, null);
      
       resultSet.close();	
    } catch (Exception exception) {
      servletDataAccess.logMessage(" *TimeEntryProjects.getProjects* -- " + exception);
      appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
    } finally {
      servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }



 
  /**/ 

  public DataSet updProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 = appletDataSet.getStringField("ProjectID");
    if(editProjects(appletDataSet,  servletDataAccess))
    	if(isNewProjects(keyField1 ,servletDataAccess))
    		appletDataSet = insertIntoProjects(appletDataSet,  servletDataAccess);
    	else 
    		appletDataSet = updateIntoProjects(appletDataSet,  servletDataAccess);	
    return appletDataSet;
  }
   

  public DataSet getNextProjectsNumber(DataSet appletDataSet,
                                             DataAccess servletDataAccess) {
      return appletDataSet;
  }

  private boolean editProjects(DataSet appletDataSet, 
                                             DataAccess servletDataAccess){
  	
      TimeEntryEmployees employee = new TimeEntryEmployees();
      TimeEntryClient client = new TimeEntryClient();
      boolean isValid = true;
      
      if(employee.isNewEmployees(appletDataSet.getStringField("EmployeeID"), servletDataAccess)) {
      	appletDataSet.addMessage("Invalid Employee ID", "30", "EmployeeID" , null);
      	isValid = false;
      }
      
      if(client.isNewClients(appletDataSet.getStringField("ClientID"), servletDataAccess)) {
      	appletDataSet.addMessage("Invalid Client ID", "30", "ClientID" , null);
      	isValid = false;
      }

      if(appletDataSet.getStringField("ProjectName").equals("")) {
  	      appletDataSet.addMessage("Invalid Project Name", "30", "ProjectName" , null);
  	      isValid = false;	
  	  }
  	  
      if(appletDataSet.getStringField("ProjectBeginDate").equals("")) {
	      appletDataSet.addMessage("Invalid Begin Date", "30", "ProjectBeginDate" , null);
	      isValid = false;	
	  }

      if(appletDataSet.getStringField("ProjectEndDate").equals("")) {
	      appletDataSet.addMessage("Invalid End Date", "30", "ProjectEndDate" , null);
	      isValid = false;	
	  }
  	  
	  return isValid;
  }


  public boolean isNewProjects(String keyfField1, DataAccess servletDataAccess){
     java.sql.ResultSet resultSet;
     java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
     boolean newRecord = false;
     try {
     	resultSet = sqlStatement.executeQuery(
     			"Select ProjectID from Projects Where ProjectID =  " + keyfField1 +" "); 
  
     	if (!resultSet.next())
     		newRecord = true;

     	resultSet.close();         
     } catch (Exception exception) {
       servletDataAccess.logMessage(" *TimeEntryProjects.isNewProjects* -- " + exception);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
     }
     return newRecord;
  }
 
  
  private DataSet insertIntoProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "", updateValues = "";
  		String updateableFields [] = appletDataSet.getUpdateableFields(); 
           for (int x = 0; x < updateableFields.length; x++) {
           if(tableFields.isValidTableColumn(updateableFields[x])) {
                String field = updateableFields[x],
	                   type  = tableFields.getFieldType(field); 
            	updateFields = servletDataAccess.addToArgumentList(updateFields, field);
            	updateValues = servletDataAccess.addToArgumentList(updateValues, "?");
            }            
           }
           sqlUpdateStatement = servletDataAccess.execPreparedConnect(
                   "Insert Into Projects (" + updateFields + " ) Values (" + updateValues + ")");
           
           for (int x = 0; x < updateableFields.length; x++) {
            if(tableFields.isValidTableColumn(updateableFields[x])) {
           	 String field = updateableFields[x],
			       type = tableFields.getFieldType(field);
           	 servletDataAccess.setPreparedValue(
           			sqlUpdateStatement,
					x + 1,
					field,
					type,
					appletDataSet);		
            }              
           }         	
            sqlUpdateStatement.executeUpdate();

            appletDataSet.addMessage("Projects Added", "10", null, null);
         } catch (Exception exception) {
            servletDataAccess.logMessage(" *TimeEntryProjects.insertIntoProjects* -- " + exception);
         	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
         } finally {
           servletDataAccess.execClose(sqlUpdateStatement);
         }
       return appletDataSet;
     }
                      

  private DataSet updateIntoProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "";
  		String updateableFields [] = appletDataSet.getUpdateableFields(); 
  		for (int x = 1; x < updateableFields.length; x++)
  			if(tableFields.isValidTableColumn(updateableFields[x]))  		
  			  updateFields = servletDataAccess.addToArgumentList(updateFields, 
  				   	  updateableFields[x]  + " = ? ");
               	
  		sqlUpdateStatement = servletDataAccess.execPreparedConnect(
  				"Update Projects SET " + updateFields + " Where ProjectID =  " + 
					appletDataSet.getStringField("ProjectID") + " ");
               	
                     for (int x = 1; x < updateableFields.length; x++) {
                      if(tableFields.isValidTableColumn(updateableFields[x])) {  		
                       	String field = updateableFields[x],
					           type = tableFields.getFieldType(field);
                       	servletDataAccess.setPreparedValue(
                   			sqlUpdateStatement,
        					x,
        					field,
        					type,
        					appletDataSet);		
                      }
                     }
                     sqlUpdateStatement.executeUpdate();
                     appletDataSet.addMessage("Projects Updated", "10", null, null);
                 } catch (Exception exception) {
                    servletDataAccess.logMessage(" *TimeEntryProjects.updateIntoProjects* -- " + exception);
                 	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
                 } finally {
                   servletDataAccess.execClose(sqlUpdateStatement);
                 }
               return appletDataSet;
             }




  /**/

  public DataSet delProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 = appletDataSet.getStringField("ProjectID");
   java.sql.Statement sqlStatement = servletDataAccess.execConnectUpdate();
     try {
       sqlStatement.executeUpdate(
       		"Delete from Projects Where ProjectID =  " + keyField1 + " ");
       appletDataSet.addMessage("Record Deleted", "10", null, null);
     }  catch (Exception exception) {
        servletDataAccess.logMessage(" *TimeEntryProjects.delProjects* -- " + exception);
     	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
    }
     return appletDataSet;
  }




 /**/
 public DataSet nxtProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 =  appletDataSet.getStringField("ProjectID");
   ResultSet resultSet;
   java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
   TimeEntryClient clients = new TimeEntryClient();
   TimeEntryEmployees employee = new TimeEntryEmployees();
   
   try {
   		resultSet = sqlStatement.executeQuery(
   			"Select * from Projects Where ProjectID >  " + keyField1 +"  Order By ProjectID");
       if (resultSet.next()) {
         for (int x = 0; x < tableFields.getColumnCount(); x++) {
        	String field = tableFields.getFieldByIndex(x),
	               type = tableFields.getFieldType(field);
        	if(type != null)
        		appletDataSet.put(field, 
         			          servletDataAccess.getFieldValue(resultSet, field, type));
         }
         
         appletDataSet = clients.getClientCompanyName(appletDataSet, servletDataAccess); 
         appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);

       } else {
       	appletDataSet.addMessage("Record Not found", "30", null, null);
       }
        resultSet.close();
      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeEntryProjects.nxtProjects* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
      }
    
    return appletDataSet;
  }




  /**/
  public DataSet prvProjects(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 =  appletDataSet.getStringField("ProjectID");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
    TimeEntryClient clients = new TimeEntryClient();
    TimeEntryEmployees employee = new TimeEntryEmployees();
    try {
    		resultSet = sqlStatement.executeQuery(
    			"Select * from Projects Where ProjectID <  " + keyField1 +"  Order By ProjectID DESC");
        if (resultSet.next()) {
          for (int x = 0; x < tableFields.getColumnCount(); x++) {
         	String field = tableFields.getFieldByIndex(x),
 	               type = tableFields.getFieldType(field);
         	if(type != null)
         		appletDataSet.put(field, 
          			          servletDataAccess.getFieldValue(resultSet, field, type));
          }
          
          appletDataSet = clients.getClientCompanyName(appletDataSet, servletDataAccess); 
          appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);

        } else {
        	appletDataSet.addMessage("Record Not found", "30", null, null);
        }
         resultSet.close();
       } catch (Exception exception) {
          servletDataAccess.logMessage(" *TimeEntryProjects.prvProjects* -- " + exception);
       	  appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
       } finally {
       	servletDataAccess.execClose(sqlStatement);
       }
     
     return appletDataSet;
   }




  /**/

  public DataSet getProjectsList(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
    String keyField1 = (String) appletDataSet.get("@ProjectID");
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("Table1");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From Projects ";
    
     
     sql = servletDataAccess.addToSearchWhereClause(sql,"ProjectID", "CHR",
     									keyField1);
     sql = servletDataAccess.addToSearchWhereClause(sql,"ProjectName", "CHR", 
     									appletDataSet.getStringField("@ProjectName"));
     sql = servletDataAccess.addToSearchWhereClause(sql,"ClientID", "INT", 
     									appletDataSet.getStringField("@ClientID"));
     sql = servletDataAccess.addToSearchWhereClause(sql,"PurchaseOrderNumber", "CHR", 
     									appletDataSet.getStringField("@PurchaseOrderNumber"));

     
    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		tableFields.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("Table1", cstmrv1);

      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeEntryProjects.hetProjectsList* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }

  
  public DataSet getProjectsListByClient(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("ProjectByClientTable");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From Projects Where ClientID = " + appletDataSet.getIntegerField("ClientID");;
    
    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		         tableFields.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("ProjectByClientTable", cstmrv1);

      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeEntryProjects.hetProjectsList* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }


 
//**************************************************************************************************** 
  class TableFieldDefinition 
        extends StandardTableDefinition { 
	TableFieldDefinition(){
		setTable(tableColumNames,tableFieldTypes);	
	}
   private final  String[] tableColumNames = {
          "ProjectID" , 
          "ProjectName" , 
          "ProjectDescription" , 
          "ClientID" , 
          "PurchaseOrderNumber" , 
          "ProjectTotalBillingEstimate" , 
          "EmployeeID" , 
          "ProjectBeginDate" , 
          "ProjectEndDate" , 

        };

    private final  String[] tableFieldTypes = {
	 "CHR", 	 // ProjectID
	 "CHR", 	 // ProjectName
	 "CHR", 	 // ProjectDescription
	 "INT", 	 // ClientID
	 "CHR", 	 // PurchaseOrderNumber
	 "CHR", 	 // ProjectTotalBillingEstimate
	 "INT", 	 // EmployeeID
	 "CHR", 	 // ProjectBeginDate
	 "CHR", 	 // ProjectEndDate

            };
   }
}
