/**
 * <p>Title: TimeEntryClientt</p>
 * <p>Description: Time Entry Client Class</p>
 *
 * 
 * @author  [User/]
 * @version 1.0
 */


/*
Class Detail Description:
  
*/


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import webBoltOns.dataContol.DataAccess;
import webBoltOns.dataContol.DataSet;
import webBoltOns.dataContol.StandardTableDefinition;


public class TimeEntryClient {

 TableFieldDefinition tableFields = new TableFieldDefinition();
 TimeEntryProjects timeEntryProjects = new TimeEntryProjects();
 
	
 public TimeEntryClient() {}
 

 
 /**/
 
 public DataSet getClients(DataSet appletDataSet, DataAccess servletDataAccess) {     
   String keyField1 =  appletDataSet.getStringField("ClientID");
    
      java.sql.ResultSet resultSet;
      java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
        try {
        	resultSet = sqlStatement.executeQuery(
          		"Select * from Clients Where ClientID = " + keyField1);
          if (resultSet.next()) 
            for (int x = 0; x < tableFields.getColumnCount(); x++) {
              String field = tableFields.getFieldByIndex(x),
			         type = tableFields.getFieldType(field);
              appletDataSet.put(field, servletDataAccess.getFieldValue(resultSet, field, type));
           
              appletDataSet = timeEntryProjects.getProjectsListByClient(appletDataSet, servletDataAccess);
        }
        else 
              appletDataSet.addMessage("Record Not found", "30", null, null);
      
      resultSet.close();	
    } catch (Exception er) {
      appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
    } finally {
      servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }


 
 public DataSet getClientNotes(DataSet appletDataSet, DataAccess servletDataAccess) {     
    String keyField1 =  appletDataSet.getStringField("ClientID");
     
       java.sql.ResultSet resultSet;
       java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
         try {
         	resultSet = sqlStatement.executeQuery(
           		"Select Notes from Clients Where ClientID = " + keyField1);
           if (resultSet.next()) 
                 appletDataSet.put("Notes", 
                 		servletDataAccess.getFieldValue(resultSet, "Notes", "CHR"));
                  
         else 
               appletDataSet.addMessage("Record Not found", "30", null, null);
       
       resultSet.close();	
     } catch (Exception er) {
       appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
     } finally {
       servletDataAccess.execClose(sqlStatement);
     }
   return appletDataSet;
   }

 
 public DataSet getClientCompanyName(DataSet appletDataSet, DataAccess servletDataAccess) {     
    String keyField1 =  appletDataSet.getStringField("ClientID");
     
       java.sql.ResultSet resultSet;
       java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
         try {
         	resultSet = sqlStatement.executeQuery(
           		"Select CompanyName from Clients Where ClientID = " + keyField1);
           if (resultSet.next()) 
            appletDataSet.put("CompanyName",
                 		servletDataAccess.getFieldValue(resultSet, "CompanyName", "CHR"));
                  
         else 
               appletDataSet.addMessage("Record Not found", "30", null, null);
       
       resultSet.close();	
     } catch (Exception er) {        
     } finally {
       servletDataAccess.execClose(sqlStatement);
     }
   return appletDataSet;
   }
 
  /**/ 

  public DataSet updClients(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 = appletDataSet.getStringField("ClientID");
    if(editClients(appletDataSet,  servletDataAccess))
    	if(isNewClients(keyField1 ,servletDataAccess))
    		appletDataSet = insertIntoClients(appletDataSet,  servletDataAccess);
    	else 
    		appletDataSet = updateIntoClients(appletDataSet,  servletDataAccess);	
    return appletDataSet;
  }
   
  
  
  
  public DataSet updClientNotes(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 = appletDataSet.getStringField("ClientID");
    String notes = appletDataSet.getStringField("Notes");
	
    if(!isNewClients(keyField1 ,servletDataAccess) && !notes.equals("")) {
       PreparedStatement sqlUpdateStatement = null;
      	try {
      		sqlUpdateStatement = servletDataAccess.execPreparedConnect(
      				"Update Clients SET Notes = ?  Where ClientID = " + 
    					appletDataSet.getStringField("ClientID"));
            servletDataAccess.setPreparedValue(
            		sqlUpdateStatement, 1, "Notes", "CHR", appletDataSet);		
            sqlUpdateStatement.executeUpdate();
            appletDataSet.addMessage("Note Pad Updated", "10", null, null);
      	} catch (Exception er) {
      		appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      	} finally {
      		servletDataAccess.execClose(sqlUpdateStatement);
      	}
    }
    return appletDataSet;
  }

  
  
  
  
  public DataSet getNextClientsNumber(DataSet appletDataSet,
                                             DataAccess servletDataAccess) {
      return appletDataSet;
  }

  private boolean editClients(DataSet appletDataSet, 
                                             DataAccess servletDataAccess){
	  return true;
  }


  public boolean isNewClients(String keyfField1, DataAccess servletDataAccess){
     java.sql.ResultSet resultSet;
     java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
     boolean newRecord = false;
     try {
     	resultSet = sqlStatement.executeQuery(
     			"Select ClientID from Clients Where ClientID = " + keyfField1 ); 
  
     	if (!resultSet.next())
     		newRecord = true;

     	resultSet.close();         
     } catch (Exception er) {
     } finally {
     	servletDataAccess.execClose(sqlStatement);
     }
     return newRecord;
  }
 
  
  private DataSet insertIntoClients(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "", updateValues = "";
           for (int x = 0; x < tableFields.getColumnCount(); x++) {
            String field = tableFields.getFieldByIndex(x),
	                       type = tableFields.getFieldType(field); 
            	updateFields = servletDataAccess.addToArgumentList(updateFields, field);
            	updateValues = servletDataAccess.addToArgumentList(updateValues, "?");
           }
           sqlUpdateStatement = servletDataAccess.execPreparedConnect(
                   "Insert Into Clients (" + updateFields + " ) Values (" + updateValues + ")");
           
           for (int x = 0; x < tableFields.getColumnCount(); x++) {
           	String field = tableFields.getFieldByIndex(x),
			       type = tableFields.getFieldType(field);
           	servletDataAccess.setPreparedValue(
           			sqlUpdateStatement,
					x + 1,
					field,
					type,
					appletDataSet);		
           }         	
            sqlUpdateStatement.executeUpdate();

            appletDataSet.addMessage("Record Updated", "10", null, null);
         } catch (Exception er) {
         	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
         } finally {
           servletDataAccess.execClose(sqlUpdateStatement);
         }
       return appletDataSet;
     }
                      

  private DataSet updateIntoClients(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "";
  		for (int x = 1; x < tableFields.getColumnCount(); x++)
  			updateFields = servletDataAccess.addToArgumentList(updateFields, 
  					tableFields.getFieldByIndex(x) + " = ? ");
               	
  		sqlUpdateStatement = servletDataAccess.execPreparedConnect(
  				"Update Clients SET " + updateFields + " Where ClientID = " + 
					appletDataSet.getStringField("ClientID"));
               	
                     for (int x = 1; x <tableFields.getColumnCount(); x++) {
                       	String field = tableFields.getFieldByIndex(x),
					           type = tableFields.getFieldType(field);
                       	servletDataAccess.setPreparedValue(
                   			sqlUpdateStatement,
        					x,
        					field,
        					type,
        					appletDataSet);		
                     }
                     sqlUpdateStatement.executeUpdate();
                     appletDataSet.addMessage("Clients Updated", "10", null, null);
                 } catch (Exception er) {
                 	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
                 } finally {
                   servletDataAccess.execClose(sqlUpdateStatement);
                 }
               return appletDataSet;
             }




  /**/

  public DataSet delClients(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 = appletDataSet.getStringField("ClientID");
   java.sql.Statement sqlStatement = servletDataAccess.execConnectUpdate();
     try {
       sqlStatement.executeUpdate(
       		"Delete from Clients Where ClientID = " + keyField1);
       appletDataSet.addMessage("Record Deleted", "10", null, null);
     }  catch (Exception er) {
     	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
    }
     return appletDataSet;
  }




 /**/
 public DataSet nxtClients(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 =  appletDataSet.getStringField("ClientID");
   ResultSet resultSet;
   java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
   try {
   		resultSet = sqlStatement.executeQuery(
   			"Select * from Clients Where ClientID > " + keyField1 +" Order By ClientID");
       if (resultSet.next()) {
         for (int x = 0; x < tableFields.getColumnCount(); x++) {
        	String field = tableFields.getFieldByIndex(x),
	               type = tableFields.getFieldType(field);
         	appletDataSet.put(field, 
         			          servletDataAccess.getFieldValue(resultSet, field, type));
         	
         	appletDataSet = timeEntryProjects.getProjectsListByClient(appletDataSet, servletDataAccess);
         }
       } else {
       	appletDataSet.addMessage("Record Not found", "30", null, null);
       }
        resultSet.close();
      } catch (Exception er) {
      	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
      }
    
    return appletDataSet;
  }




  /**/
  public DataSet prvClients(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 =  appletDataSet.getStringField("ClientID");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
    try {
    		resultSet = sqlStatement.executeQuery(
    			"Select * from Clients Where ClientID < " + keyField1 +" Order By ClientID DESC");
        if (resultSet.next()) {
          for (int x = 0; x < tableFields.getColumnCount(); x++) {
         	String field = tableFields.getFieldByIndex(x),
 	               type = tableFields.getFieldType(field);
          	appletDataSet.put(field, 
          			          servletDataAccess.getFieldValue(resultSet, field, type));
          	
          	appletDataSet = timeEntryProjects.getProjectsListByClient(appletDataSet, servletDataAccess);
          }
        } else {
        	appletDataSet.addMessage("Record Not found", "30", null, null);
        }
         resultSet.close();
       } catch (Exception er) {
       	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
       } finally {
       	servletDataAccess.execClose(sqlStatement);
       }
     
     return appletDataSet;
   }




  /**/

  public DataSet getClientsList(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
    String keyField1 = (String) appletDataSet.get("@ClientID");
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("Table1");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From Clients ";
    
     sql = servletDataAccess.addToSearchWhereClause(sql,"ClientID", "CHR", keyField1);

    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		tableFields.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("Table1", cstmrv1);


      } catch (Exception er) {
      	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }


 

  class TableFieldDefinition 
        extends StandardTableDefinition { 
	TableFieldDefinition(){
		setTable(tableColumNames,tableFieldTypes);	
	}
   private final  String[] tableColumNames = {
          "ClientID" , 
          "CompanyName" , 
          "Address" , 
          "City" , 
          "StateOrProvince" , 
          "PostalCode" , 
          "Country" , 
          "ContactFirstName" , 
          "ContactLastName" , 
          "ContactTitle" , 
          "PhoneNumber" , 
          "FaxNumber" , 
          "ReferredBy" , 
          "Notes" , 

        };

    private final  String[] tableFieldTypes = {
	 "INT", 	 // ClientID
	 "CHR", 	 // CompanyName
	 "CHR", 	 // Address
	 "CHR", 	 // City
	 "CHR", 	 // StateOrProvince
	 "CHR", 	 // PostalCode
	 "CHR", 	 // Country
	 "CHR", 	 // ContactFirstName
	 "CHR", 	 // ContactLastName
	 "CHR", 	 // ContactTitle
	 "CHR", 	 // PhoneNumber
	 "CHR", 	 // FaxNumber
	 "CHR", 	 // ReferredBy
	 "CHR", 	 // Notes

            };
   }
}
