/**
 * <p>Title: TimeEntryTimeCardst</p>
 * <p>Description: </p>
 *
 * 
 * @author  [User/]
 * @version 1.0
 */


/*
Class Detail Description:
  
*/


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import webBoltOns.dataContol.DataAccess;
import webBoltOns.dataContol.DataSet;
import webBoltOns.dataContol.StandardTableDefinition;


public class TimeEntryTimeCards {

 TableFieldDefinition tableFields = new TableFieldDefinition();

 TimeEntryFieldDefinition timeEntryFieldDefinition = new TimeEntryFieldDefinition();

 public TimeEntryTimeCards() {}
 

 
 /**/
 
 public DataSet getTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {     
   String keyField1 =  appletDataSet.getStringField("TimeCardID");
      java.sql.ResultSet resultSet;
      java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
      TimeEntryEmployees employee = new TimeEntryEmployees();  
       try {
        	resultSet = sqlStatement.executeQuery(
          		"Select * from [Time Cards] Where TimeCardID = " + keyField1);
          if (resultSet.next()) 
            for (int x = 0; x < tableFields.getColumnCount(); x++) {
              String field = tableFields.getFieldByIndex(x),
			         type = tableFields.getFieldType(field);
              appletDataSet.put(field, servletDataAccess.getFieldValue(resultSet, field, type));

           appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);          
           appletDataSet = getTimeCardHours(appletDataSet, servletDataAccess);
           }  
        else 
              appletDataSet.addMessage("Record Not found", "30", null, null);
      
      resultSet.close();	
    } catch (Exception er) {
      appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
    } finally {
      servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }



 
  /**/ 

  public DataSet updTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 = appletDataSet.getStringField("TimeCardID");
    if(editTimeCards(appletDataSet,  servletDataAccess))
    	if(isNewTimeCards(keyField1 ,servletDataAccess))
    		appletDataSet = insertIntoTimeCards(appletDataSet,  servletDataAccess);
    	else 
    		appletDataSet = updateIntoTimeCards(appletDataSet,  servletDataAccess);	
    return appletDataSet;
  }
   

  public DataSet getNextTimeCardsNumber(DataSet appletDataSet,
                                             DataAccess servletDataAccess) {
      return appletDataSet;
  }

  private boolean editTimeCards(DataSet appletDataSet, 
                                             DataAccess servletDataAccess){
	  return true;
  }


  public boolean isNewTimeCards(String keyfField1, DataAccess servletDataAccess){
     java.sql.ResultSet resultSet;
     java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
     boolean newRecord = false;
     try {
     	resultSet = sqlStatement.executeQuery(
     			"Select TimeCardID from [Time Cards] Where TimeCardID = " + keyfField1); 
  
     	if (!resultSet.next())
     		newRecord = true;

     	resultSet.close();         
     } catch (Exception er) {
     } finally {
     	servletDataAccess.execClose(sqlStatement);
     }
     return newRecord;
  }
 
  
  private DataSet insertIntoTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "", updateValues = "";
           for (int x = 0; x < tableFields.getColumnCount(); x++) {
            String field = tableFields.getFieldByIndex(x),
	                       type = tableFields.getFieldType(field); 
            	updateFields = servletDataAccess.addToArgumentList(updateFields, field);
            	updateValues = servletDataAccess.addToArgumentList(updateValues, "?");
           }
           sqlUpdateStatement = servletDataAccess.execPreparedConnect(
                   "Insert Into [Time Cards] (" + updateFields + " ) Values (" + updateValues + ")");
           
           for (int x = 0; x < tableFields.getColumnCount(); x++) {
           	String field = tableFields.getFieldByIndex(x),
			       type = tableFields.getFieldType(field);
           	servletDataAccess.setPreparedValue(
           			sqlUpdateStatement,
					x + 1,
					field,
					type,
					appletDataSet);		
           }         	
            sqlUpdateStatement.executeUpdate();

            appletDataSet.addMessage("Record Updated", "10", null, null);
         } catch (Exception er) {
         	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
         } finally {
           servletDataAccess.execClose(sqlUpdateStatement);
         }
       return appletDataSet;
     }
                      

  private DataSet updateIntoTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
  	PreparedStatement sqlUpdateStatement = null;
  	try {
  		String updateFields = "";
  		for (int x = 1; x < tableFields.getColumnCount(); x++)
  			updateFields = servletDataAccess.addToArgumentList(updateFields, 
  					tableFields.getFieldByIndex(x) + " = ? ");
               	
  		sqlUpdateStatement = servletDataAccess.execPreparedConnect(
  				"Update [Time Cards] SET " + updateFields + " Where TimeCardID = " + 
					appletDataSet.getStringField("TimeCardID"));
               	
                     for (int x = 1; x <tableFields.getColumnCount(); x++) {
                       	String field = tableFields.getFieldByIndex(x),
					           type = tableFields.getFieldType(field);
                       	servletDataAccess.setPreparedValue(
                   			sqlUpdateStatement,
        					x,
        					field,
        					type,
        					appletDataSet);		
                     }
                     sqlUpdateStatement.executeUpdate();
                     appletDataSet.addMessage("[Time Cards] Updated", "10", null, null);
                 } catch (Exception er) {
                 	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
                 } finally {
                   servletDataAccess.execClose(sqlUpdateStatement);
                 }
               return appletDataSet;
             }




  /**/

  public DataSet delTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 = appletDataSet.getStringField("TimeCardID");
   java.sql.Statement sqlStatement = servletDataAccess.execConnectUpdate();
     try {
       sqlStatement.executeUpdate(
       		"Delete from [Time Cards] Where TimeCardID = " + keyField1);
       appletDataSet.addMessage("Record Deleted", "10", null, null);
     }  catch (Exception er) {
     	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
     } finally {
     	servletDataAccess.execClose(sqlStatement);
    }
     return appletDataSet;
  }




 /**/
 public DataSet nxtTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
   String keyField1 =  appletDataSet.getStringField("TimeCardID");
   ResultSet resultSet;
   java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
   TimeEntryEmployees employee = new TimeEntryEmployees();
   try {
   		resultSet = sqlStatement.executeQuery(
   			"Select * from [Time Cards] Where TimeCardID > " + keyField1 +" Order By TimeCardID");
       if (resultSet.next()) {
         for (int x = 0; x < tableFields.getColumnCount(); x++) {
        	String field = tableFields.getFieldByIndex(x),
	               type = tableFields.getFieldType(field);
         	appletDataSet.put(field, 
         			          servletDataAccess.getFieldValue(resultSet, field, type));
            
         	appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);
            appletDataSet = getTimeCardHours(appletDataSet, servletDataAccess);
          }
       } else {
       	appletDataSet.addMessage("Record Not found", "30", null, null);
       }
        resultSet.close();
      } catch (Exception er) {
      	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
      }
    
    return appletDataSet;
  }




  /**/
  public DataSet prvTimeCards(DataSet appletDataSet, DataAccess servletDataAccess) {
    String keyField1 =  appletDataSet.getStringField("TimeCardID");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();
    TimeEntryEmployees employee = new TimeEntryEmployees();
    try {
    		resultSet = sqlStatement.executeQuery(
    			"Select * from [Time Cards] Where TimeCardID < " + keyField1 +" Order By TimeCardID DESC");
        if (resultSet.next()) {
          for (int x = 0; x < tableFields.getColumnCount(); x++) {
         	String field = tableFields.getFieldByIndex(x),
 	               type = tableFields.getFieldType(field);
          	appletDataSet.put(field, 
          			          servletDataAccess.getFieldValue(resultSet, field, type));
            
          	appletDataSet = employee.getEmployeeName(appletDataSet, servletDataAccess);
          	appletDataSet = getTimeCardHours(appletDataSet, servletDataAccess);
           }
        } else {
        	appletDataSet.addMessage("Record Not found", "30", null, null);
        }
         resultSet.close();
       } catch (Exception er) {
       	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
       } finally {
       	servletDataAccess.execClose(sqlStatement);
       }
     
     return appletDataSet;
   }




  /**/

  public DataSet getTimeCardsList(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
    String keyField1 = (String) appletDataSet.get("@TimeCardID");
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("TimeCardTable");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From [Time Cards] ";
    
     sql = servletDataAccess.addToSearchWhereClause(sql,"TimeCardID", "CHR", keyField1);

    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) { 
             
        	tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		tableFields.getFieldType(tableColumnFieldsArray1[x]));
        
        }
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("TimeCardTable", cstmrv1);


      } catch (Exception er) {
      	appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }

  public DataSet getTimeCardHours(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
   
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("TimeCardHoursTable");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From [Time Card Hours] Where TimeCardID = " + appletDataSet.getIntegerField("TimeCardID");

    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		timeEntryFieldDefinition.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("TimeCardHoursTable", cstmrv1);

      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeCardHours.getTimeCardHours* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }

 
  
  public DataSet getTimeCardExpenses(DataSet appletDataSet, DataAccess servletDataAccess) {  
    Vector cstmrv1 = new Vector();
   
    String[] tableColumnFieldsArray1 = (String[]) appletDataSet.getTableColumnFields("TimeCardExpensesTable");
    ResultSet resultSet;
    java.sql.Statement sqlStatement = servletDataAccess.execConnectReadOnly();;


    String sql = "Select " + servletDataAccess.buildArgumentList(tableColumnFieldsArray1) +
	"  From [Time Card Expenses] Where TimeCardID = " + appletDataSet.getIntegerField("TimeCardID");

    try {
      resultSet = sqlStatement.executeQuery(sql);
      while (resultSet.next()) {
        String[] tabelRow1 = new String[tableColumnFieldsArray1.length];
        for (int x = 0; x < tableColumnFieldsArray1.length; x++) 
          tabelRow1[x] = (String) servletDataAccess.getFieldValue(resultSet, tableColumnFieldsArray1[x],
          		timeEntryFieldDefinition.getFieldType(tableColumnFieldsArray1[x]));
        
        cstmrv1.addElement(tabelRow1);

        }
        resultSet.close();
        appletDataSet.put("TimeCardExpensesTable", cstmrv1);

      } catch (Exception exception) {
         servletDataAccess.logMessage(" *TimeCardHours.getTimeCardExpenses* -- " + exception);
      	 appletDataSet.addMessage("Database Error - Please contact systems administrator", "30", null, null);
      } finally {
      	servletDataAccess.execClose(sqlStatement);
    }
  return appletDataSet;
  }

 


  
  
  
  class TableFieldDefinition 
        extends StandardTableDefinition { 
	TableFieldDefinition(){
		setTable(tableColumNames,tableFieldTypes);	
	}
   private final  String[] tableColumNames = {
          "TimeCardID" , 
          "EmployeeID" , 
          "DateEntered" , 

        };

    private final  String[] tableFieldTypes = {
	 "CHR", 	 // TimeCardID
	 "INT", 	 // EmployeeID
	 "CHR", 	 // DateEntered

            };
   }


  //**************************************************************************************************** 
  class TimeEntryFieldDefinition 
        extends StandardTableDefinition { 
  	TimeEntryFieldDefinition(){
		setTable(tableColumNames,tableFieldTypes);	
	}
   private final  String[] tableColumNames = {
          "TimeCardDetailID" , 
          "TimeCardID" , 
          "DateWorked" , 
          "ProjectID" , 
          "WorkDescription" , 
          "BillableHours" , 
          "BillingRate" , 
          "WorkCodeID" , 

        };

    private final  String[] tableFieldTypes = {
	 "CHR", 	 // TimeCardDetailID
	 "INT", 	 // TimeCardID
	 "CHR", 	 // DateWorked
	 "INT", 	 // ProjectID
	 "CHR", 	 // WorkDescription
	 "FLT", 	 // BillableHours
	 "CHR", 	 // BillingRate
	 "INT", 	 // WorkCodeID

            };
   }
}
