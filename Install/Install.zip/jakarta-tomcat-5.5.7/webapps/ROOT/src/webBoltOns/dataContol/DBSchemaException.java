package webBoltOns.dataContol;

public class DBSchemaException extends Exception {

	private static final long serialVersionUID = 1L;

}
